=== MF Newsletter ===
Contributors: Commercepundit
Tags: newsletter
Requires at least: 4.0
Tested up to: 4.6.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Mutualfame Newsletter form with sortcode to show anywhere on website.

== Description ==

Mutualfame Newsletter plugin can be added on any post or pages by just adding sortcode [mf_newsletter].
Allow to Add Full name and Mobile Number in newsletter form , in admin if ticked then it will be display on Newsletter form. Also user can change Label of button from admin. Adminside there will list of subscribed users. and admin can also search and delete.Once User subscribed mail will be sent with unsubscibe link , Once New post will publish on website subscibed users will get post notification mail. if user wants to stop getting mail then click on Unsubscribed link in mail.


== Installation ==

1. Upload the entire `mf-newsletter` folder to the `/wp-content/plugins/` directory.

2. Activate the plugin through the 'Plugins' menu in WordPress.

You will find 'MF Newsletter' Menu at left side in your WordPress admin panel.

== Screenshots ==

1. screenshot-1.png

2. screenshot-2.png